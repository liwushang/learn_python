def send(text):
    print("the file %s is sending..." % text)