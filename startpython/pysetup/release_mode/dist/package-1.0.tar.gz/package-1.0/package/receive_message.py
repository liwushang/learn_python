def receive():
    return "which comes from 100xx"